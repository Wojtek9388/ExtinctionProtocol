// priority: 0

// Visit the wiki for more info - https://kubejs.com/

console.info('Hello, World! (Loaded server scripts)')

ServerEvents.loaded(event => {
    // Loop through all online players
    event.server.players.forEach(player => {
        player.playSound('minecraft:entity.experience_orb.pickup', {
            volume: 1.0,
            pitch: 1.0
        })
    })
})