ServerEvents.tags('item', event => {
    // Add tobacco seeds to fertile season tags.
    event.add('sereneseasons:spring_crops', 'the_dirty_stuff:tobacco_seeds')
    event.add('sereneseasons:summer_crops', 'the_dirty_stuff:tobacco_seeds')
    event.add('sereneseasons:autumn_earl_cropsy', 'the_dirty_stuff:tobacco_seeds')

    // Add ephedra seeds to fertile season tags.
    event.add('sereneseasons:spring_crops', 'createbb:ephedra_seeds')
    event.add('sereneseasons:summer_crops', 'createbb:ephedra_seeds')
    event.add('sereneseasons:autumn_earl_cropsy', 'createbb:ephedra_seeds')
})