ItemEvents.foodEaten(event => {
    const item = event.item

    if (item.id == 'estrogen:horse_urine_bottle') {
        const player = event.player

        console.info("Horse urine drank.")
        console.info(player)

        player.potionEffects.add('minecraft:nausea', 200, 0) // 10 seconds of nausea at default levels.
        player.potionEffects.add('toughasnails:thirst', 200, 10) // 10 seconds of thirst at level 10.
    }
})